# Design System Specification: The Curated Social

## 1. Overview & Creative North Star
**Creative North Star: "The Ethereal Editorial"**

This design system is not a utility; it is a concierge. To serve an audience of adults (30+) seeking connection without the noise, the UI must act as a calming, high-end gallery space. We are moving away from "App-like" interfaces—characterized by heavy borders and rigid grids—and moving toward a "Digital Editorial" experience.

The design breaks the standard template through **Intentional Asymmetry** and **Tonal Depth**. By utilizing generous whitespace (the "Breath" of the system) and overlapping elements, we create a sense of physical layering. The goal is to reduce cognitive load by presenting only what is necessary, wrapped in an aesthetic that feels exclusive, soft, and profoundly intentional.

---

## 2. Colors & Surface Architecture
Our palette relies on the sophistication of neutrals and the warmth of "Soft Pink" (`primary`).

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders to define sections. 
Boundaries must be created through:
*   **Background Shifts:** Transitioning from `surface` (#faf9f8) to `surface-container-low` (#f3f4f3).
*   **Tonal Transitions:** Using subtle shifts in the neutral scale to imply structure without the "boxiness" of traditional UI.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, premium paper stocks.
*   **Base:** `surface` (#faf9f8) provides a warm, off-white foundation.
*   **Nesting:** Place a `surface-container-lowest` (#ffffff) card inside a `surface-container` (#edeeed) section to create a natural, soft lift.
*   **The Glass Rule:** For floating navigation or modal overlays, use `surface` at 80% opacity with a `24px` backdrop-blur. This "Glassmorphism" ensures the brand colors bleed through, maintaining a sense of place.

### Signature Textures
Avoid flat, dead fills for primary actions. Utilize a **Signature Glow**:
*   **Primary CTA Background:** A linear gradient from `primary` (#7d545b) to `primary_container` (#f1bcc4) at a 135-degree angle. This adds "soul" and a tactile, silk-like quality to buttons.

---

## 3. Typography
The typography is the "Voice" of the club: authoritative yet conversational.

*   **Display & Headlines (Manrope):** Chosen for its geometric purity and modern proportions. Use `display-lg` for hero moments with negative letter-spacing (-0.02em) to create a high-fashion, editorial look.
*   **Body & Titles (Plus Jakarta Sans):** A highly legible sans-serif with a friendly, open aperture. 
    *   **Body-lg:** Use for long-form reading to combat eye strain.
    *   **Label-md:** Set in `on_surface_variant` (#5d605f) for secondary information, ensuring it recedes while remaining legible.
*   **Hierarchy Note:** Always maintain a high contrast between `display` (Dark Grey `on_surface` #303333) and the background. Never use pure black; it is too harsh for the "Ethereal" aesthetic.

---

## 4. Elevation & Depth
In this system, elevation is a feeling, not a drop shadow.

*   **Tonal Layering:** Depth is achieved by "stacking" surface tiers. An inner container should always be lighter (`surface-container-lowest`) than its parent (`surface-container-low`) to simulate light hitting the top-most layer.
*   **Ambient Shadows:** If a floating element (like a FAB or Menu) requires a shadow, use: 
    *   `box-shadow: 0 12px 40px rgba(125, 84, 91, 0.06);` 
    *   Note the use of a tinted shadow (using the `primary` hue) rather than grey.
*   **The "Ghost Border" Fallback:** If accessibility requires a stroke, use `outline-variant` (#b0b2b1) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons (The "Soft Touch")
*   **Primary:** Gradient fill (Primary to Primary-Container), `xl` (1.5rem) corner radius. Typography: `title-sm` in `on_primary`.
*   **Secondary:** Ghost style. No border. `on_surface` text with a subtle `surface-container-high` background on hover.
*   **Tertiary:** Underlined `label-md`. The underline should be 1px and offset by 4px.

### Cards & Lists (The "Breath" Layout)
*   **Forbid Dividers:** Never use a horizontal line to separate list items. Use `24px` of vertical whitespace (Spacing Scale) or a alternating subtle background shift.
*   **Cards:** Use `xl` (1.5rem) corner radius. Padding must be generous (minimum 32px) to ensure content never feels "trapped."

### Inputs (The "Quiet Field")
*   **Style:** Minimalist. Use `surface-container-low` as the field fill with a bottom-only `outline-variant` (20% opacity). On focus, the bottom border transforms into a 2px `primary` line.

### Exclusive Component: The "Curated Highlight"
*   **The Experience Card:** A large-scale card using a `primary_container` background, featuring an asymmetrical image crop and `display-sm` typography. Used for featured social events.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins (e.g., 10% left, 15% right) for editorial layouts.
*   **Do** lean into `xl` (1.5rem) and `full` (9999px) roundedness to maintain the "welcoming" vibe.
*   **Do** use "Soft Pink" (`primary`) sparingly—it is a diamond, not the wall. Use it to draw the eye to a single point of intent.

### Don't
*   **Don't** use 100% opaque borders. They create "visual friction" and look cheap.
*   **Don't** cram information. If a screen feels full, split it into a step-by-step flow to reduce decision fatigue.
*   **Don't** use standard "Blue" for links. Use `primary` or `secondary` to maintain the sophisticated color story.